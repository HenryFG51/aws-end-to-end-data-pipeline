import logging
import sys


class LoggerFactory(object):
    """Encapsulates Python Logging"""

    def __init__(self, log_level, log_name: str):
        """
        Constructor method

        :param log_level: logging level
        :type log_level: string
        """
        self.log_level = log_level
        self.logger = logging.getLogger(log_name)
        self.logger.propagate = False

    def get_logger(self):
        """
        Returns a python logger object

        :return: logger
        :rtype: logging.logger
        """
        try:
            msg_format = '%(asctime)s - %(levelname)s - %(name)s: %(message)s'

            handler = logging.StreamHandler(sys.stdout)
            formatter = logging.Formatter(msg_format)
            handler.setFormatter(formatter)
            self.logger.addHandler(handler)

            formatter.datefmt = "%Y-%m-%d %H:%M:%S"

            self.logger.propagate = False

            if self.log_level == "INFO":
                self.logger.setLevel(logging.INFO)

            elif self.log_level == "FATAL":
                self.logger.setLevel(logging.FATAL)

            elif self.log_level == "CRITICAL":
                self.logger.setLevel(logging.CRITICAL)

            elif self.log_level == "ERROR":
                self.logger.setLevel(logging.ERROR)

            elif self.log_level == "WARNING":
                self.logger.setLevel(logging.WARNING)

            elif self.log_level == "DEBUG":
                self.logger.setLevel(logging.DEBUG)
        except Exception as err:
            print(err)
            raise

        return self.logger
