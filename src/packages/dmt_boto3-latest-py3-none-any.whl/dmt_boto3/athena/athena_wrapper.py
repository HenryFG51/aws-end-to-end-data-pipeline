import logging
import boto3
from botocore.exceptions import ClientError
from dmt_boto3.s3.s3_wrapper import DMTS3
from dmt_boto3.retry.retry_wrapper import retry
import io
import pandas as pd

logger = logging.getLogger(__name__)

from dmt_boto3.athena.athena_exceptions import QueryStillRunningException, QueryFailedException, QueryCancelledException


class DMTAthena(object):
    """Encapsulates an Amazon Athena object"""

    def __init__(self, database_name, s3_output_path, dmt_s3: DMTS3, region_name=None, aws_access_key_id=None,
                 aws_secret_access_key=None, profile_name=None):
        """
        Constructor method

        It can connect to AWS by:
        * Profile - In this case secret and key should be None
        * Secret/Key - In this case profile should be None
        * AWS Role (Glue, Lambda, etc) - In this case Profile, Secret and Key should be None

        :param region_name: Session region name, defaults to None
        :type region_name: str, optional

        :param aws_access_key_id: AWS Key ID, defaults to None
        :type aws_access_key_id: str, optional

        :param aws_secret_access_key: AWS Secret Key, defaults to None
        :type aws_secret_access_key: str, optional

        :param profile_name: aws profile name, defaults to None
        :type profile_name: str, optional


        :param database_name: Athena DB name
        :type database_name: str

        :param s3_output_path: S3 Athena temp folder
        :type s3_output_path: str

        :return: None
        :rtype: None
        """
        self.region_name = region_name
        self.aws_access_key_id = aws_access_key_id
        self.aws_secret_access_key = aws_secret_access_key
        self.profile_name = profile_name

        self.athena_client = self.get_athena_client()
        self.s3_resource = dmt_s3
        self.s3_output_path = s3_output_path
        self.database_name = database_name

    def get_athena_client(self):
        """
        Stores the athena client in a member variable.

        :return: athena client
        :rtype: boto3.client.athena
        """
        try:
            session = boto3.session.Session(region_name=self.region_name,
                                            aws_access_key_id=self.aws_access_key_id,
                                            aws_secret_access_key=self.aws_secret_access_key,
                                            profile_name=self.profile_name)

            client = session.client('athena')
        except ClientError as err:
            logger.error(
                "Could not create a Boto3 client to %s. Here's why: %s:",
                err.response['Error']['Code'], err.response['Error']['Message'])
            logger.error(err, exc_info=True)
            raise
        except Exception as err:
            logger.error(err, exc_info=True)
            raise
        else:
            return client

    @retry(max_retries=50, exceptions=(QueryStillRunningException), interval=30, logger=logger)
    def check_query_status(self, query_execution_id):
        """
        Check Athena query status

        Waits for a maximum 25 minutes. For longer query call execute_query with run_async=True

        :param query_execution_id: Athena query_execution_id
        :type query_execution_id: string

        :return: Athena query status
        :rtype: string, QueryExecutionStatus
        """
        try:

            res = self.athena_client.get_query_execution(
                QueryExecutionId=query_execution_id)

            status = res['QueryExecution']['Status']['State']

            if status in ['SUCCEEDED', 'FAILED', 'CANCELLED']:
                return status
            else:
                raise QueryStillRunningException("Athena query still running")

        except Exception as err:
            logger.info(
                "Athena Query timed out. Try again using async call method")
            logger.error(err, exc_info=True)
            raise

    def execute_query(self, query, delete_results=True, run_async=False, workgroup='primary'):
        """
        Execute an Athena query

        If run_async is false, returns dataframe and query id. If true, returns just the query id

        :param query: Athena query
        :type query: string

        :param delete_results: If the result should be removed from S3 after execution, defaults to True
        :type delete_results: bool

        :param run_async: If True the function wil return only the query_id else will return query_id and a pandas DF, defaults to False
        :type run_async: bool

        :return: Athena results as Pandas DF and QueryExecutionId
        :rtype: tuple(pd.pd.DataFrame, str)
        """

        output_location = f"s3://{self.s3_resource.s3_bucket}/{self.s3_output_path}/athena_temp/"

        response = self.athena_client.start_query_execution(
            QueryString=query,
            QueryExecutionContext={
                'Database': self.database_name
            },
            ResultConfiguration={
                'OutputLocation': output_location,
            },
            WorkGroup=workgroup
        )

        query_id = response['QueryExecutionId']

        if run_async:
            return query_id, None
        else:
            status = self.check_query_status(query_id)

            df = self.get_result(query_id, delete_results=delete_results)

            return query_id, df

    def get_result(self, query_id, delete_results=True):
        """
        Get the Athena query results

        If run_async is false, returns dataframe and query id. If true, returns just the query id

        :param query_id: Athena QueryExecutionId
        :type query_id: string

        :param delete_results: If the result should be removed from S3 after execution, defaults to True
        :type delete_results: bool

        :return: Athena results as Pandas DF
        :rtype: pd.pd.DataFrame
        """
        try:
            res = self.athena_client.get_query_execution(
                QueryExecutionId=query_id)

            s3_out_path = res['QueryExecution']['ResultConfiguration']['OutputLocation']

            s3_key = s3_out_path.replace(
                f"s3://{self.s3_resource.s3_bucket}/", "")

            if res['QueryExecution']['Status']['State'] == 'SUCCEEDED':

                obj = self.s3_resource.s3_client.get_object(
                    Bucket=self.s3_resource.s3_bucket, Key=s3_key)

                df = pd.read_csv(io.BytesIO(obj['Body'].read()))

                if delete_results:
                    self.s3_resource.s3_client.delete_object(
                        Bucket=self.s3_resource.s3_bucket, Key=s3_key)
                    self.s3_resource.s3_client.delete_object(
                        Bucket=self.s3_resource.s3_bucket, Key=f"{s3_key}.metadata")

                return df

            elif res['QueryExecution']['Status']['State'] == 'CANCELLED':
                raise QueryCancelledException('Query Cancelled.', res)
            elif res['QueryExecution']['Status']['State'] == 'FAILED':
                raise QueryFailedException('Query failed.', res)
            elif res['QueryExecution']['Status']['State'] in ('RUNNING', 'QUEUED'):
                raise QueryStillRunningException(
                    'Athena query still running')
            else:
                raise Exception('Error executing athena query')

        except Exception as exc:
            logger.error(exc, exc_info=True)
            raise
