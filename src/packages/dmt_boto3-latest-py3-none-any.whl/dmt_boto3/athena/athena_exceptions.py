class QueryStillRunningException(Exception):
    pass


class QueryFailedException(Exception):
    pass


class QueryCancelledException(Exception):
    pass
