import time
import logging

logging_logger = logging.getLogger(__name__)


def retry(max_retries, exceptions, interval, logger=logging_logger):
    """
    Encapsulates Python Retry decorator 

    Retry the function x times if a exception happen

    :param max_retries: max request retries, defaults to 3
    :type max_retries: int, optional

    :param interval: interval, in seconds, between retries, defaults to 61
    :type interval:  int, optional

    :param Exceptions: Lists of exceptions that trigger a retry attempt
    :type Exceptions: Tuple of Exceptions

    :param logger: Log instance
    :type logger: logging.logger    
    """

    def decor(func):
        def newfn(*args, **kwargs):
            attempt = 0
            while attempt < max_retries:
                try:
                    return func(*args, **kwargs)
                except exceptions:
                    logger.info(
                        "Exception thrown when executing: %s. attempt: %s of %d. Waiting %s seconds before next call",
                        func, attempt + 1, max_retries, interval)

                    attempt += 1
                    time.sleep(interval)
            return func(*args, **kwargs)
        return newfn
    return decor
