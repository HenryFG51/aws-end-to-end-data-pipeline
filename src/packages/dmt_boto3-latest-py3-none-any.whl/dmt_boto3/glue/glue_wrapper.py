import logging

import boto3
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)


class DMTGlue(object):
    """Encapsulates an AWS Glue Object"""

    def __init__(self, region_name=None, aws_access_key_id=None,
                 aws_secret_access_key=None, profile_name=None):
        """
        Constructor method

        It can connect to AWS by:
        * Profile - In this case secret and key should be None
        * Secret/Key - In this case profile should be None
        * AWS Role (Glue, Lambda, etc) - In this case Profile, Secret and Key should be None

        :param region_name: Session region name, defaults to None
        :type region_name: str, optional

        :param aws_access_key_id: AWS Key ID, defaults to None.
        :type aws_access_key_id: str, optional

        :param aws_secret_access_key: AWS Secret Key, defaults to None.
        :type aws_secret_access_key: str, optional

        :param profile_name: aws profile name, defaults to None.
        :type profile_name: str, optional

        :return: None
        :rtype: None
        """

        self.region_name = region_name
        self.aws_access_key_id = aws_access_key_id
        self.aws_secret_access_key = aws_secret_access_key
        self.profile_name = profile_name

        self.glue_client = self.get_client()

    def get_client(self):
        """
        Stores the Glue client in a member variable.

        :return: Glue Client
        :rtype: boto3.client.glue
        """
        try:
            session = boto3.session.Session(region_name=self.region_name,
                                            aws_access_key_id=self.aws_access_key_id,
                                            aws_secret_access_key=self.aws_secret_access_key,
                                            profile_name=self.profile_name)

            client = session.client(
                service_name='glue'
            )
        except ClientError as err:
            logger.error(
                "Could not create a Boto3 client. Here's why: %s: %s",
                err.response['Error']['Code'], err.response['Error']['Message'])
            logger.error(err, exc_info=True)
            raise
        except Exception as err:
            logger.error(err, exc_info=True)
            raise
        else:
            return client

    def start_glue_crawler(self, crawler_name):
        """
        Start a Glue Crawler job

        :param crawler_name: crawler_name name
        :type crawler_name: str

        :return: Glue Start Crawler response, If the action is successful, the service sends back an HTTP 200 response with an empty HTTP body.
        :rtype: JSON
        """

        try:
            response = self.glue_client.start_crawler(Name=crawler_name)

            return response
        except ClientError as err:
            logger.error(
                "Couldn't start crawler %s, %s, %s",
                {crawler_name}, {err.response['Error']['Code']}, {err.response['Error']['Message']})
            logger.error(err, exc_info=True)
            raise
        except Exception as err:
            logger.error(err, exc_info=True)
            raise
