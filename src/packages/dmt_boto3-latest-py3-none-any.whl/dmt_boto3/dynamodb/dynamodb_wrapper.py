import logging

import awswrangler as wr
import boto3
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)


class DMTDynamoDB:
    """Encapsulates an Amazon DynamoDB (awswrangler) table"""

    def __init__(self, table_name: str):
        """
        Constructor method

        :param table_name: DynamoDB table name
        :type table_name: str

        :return: None
        :rtype: None
        """
        self.table_name = table_name

    def get_topn_by_partition(
        self, partition_name, partition_value, scan_index_forward: bool, row_count: int
    ):
        """
        Get the top(N) itens by partition, sorted by sort key

        :param partition_name: partition name
        :type partition_name: str

        :param partition_value: partition value
        :type partition_value: str

        :param scan_index_forward: sort order (False=DESC, True=ASC)
        :type scan_index_forward: bool

        :param row_count: How many top rows to return
        :type row_count: int

        :return: DynamoDB Item
        :rtype: dict
        """
        try:

            query_kwargs = {
                "ExpressionAttributeNames": {
                    "#n0": partition_name,
                },
                "ExpressionAttributeValues": {
                    ":v0": partition_value,
                },
                "KeyConditionExpression": "(#n0 = :v0)",
                "ScanIndexForward": scan_index_forward,
                "Limit": row_count,
            }

            dyn_table = wr.dynamodb.get_table(self.table_name)

            response = dyn_table.query(**query_kwargs)

            data = response["Items"]

            return data

        except ClientError as err:
            logger.error(
                "Couldn't query the table %s. %s, %s",
                {self.table.name},
                {err.response["Error"]["Code"]},
                {err.response["Error"]["Message"]},
            )
            logger.error(err, exc_info=True)
            raise
        except Exception as err:
            logger.error(err, exc_info=True)
            raise
