import logging
import os

import ibm_db
import ibm_db_dbi
import pandas as pd

from dmt_boto3.logging.logging_wrapper import LoggerFactory
from dmt_boto3.retry.retry_wrapper import retry

logger = LoggerFactory(
    log_level="INFO", log_name='edw_wrapper').get_logger()


class DMTEDW(object):
    """Encapsulates an EDW DB2 object"""

    def __init__(self, edw_hostname: str, edw_user: str, edw_pw: str, edw_database: str):
        """
        Constructor method

        :param edw_hostname: hostname
        :type edw_hostname: str

        :param edw_user: User name
        :type edw_user: str

        :param edw_pw: User pw
        :type edw_pw: str

        :param edw_database: DB name
        :type edw_database: str

        :return: None
        :rtype: None
        """
        self.hostname = edw_hostname
        self.user = edw_user
        self.user_pw = edw_pw
        self.database = edw_database

        self.db_connection = self.get_db_connection(
            hostname=self.hostname, database=self.database, user=self.user, user_pw=self.user_pw)

    def get_db_connection(self, hostname: str, database: str, user: str, user_pw: str) -> ibm_db_dbi.Connection:
        """
        Get a DB2 connection

        :param hostname: DB2 hostname
        :type hostname: string

        :param database: DB2 database
        :type database: string

        :param user: DB2 user
        :type user: string

        :param user_pw: DB2 user_pw
        :type user_pw: string

        :param hostname: DB2 hostname
        :type hostname: string

        :return: DB2 connection
        :rtype: ibm_db_dbi.Connection
        """
        conn_string = f"DATABASE={database}; HOSTNAME={hostname}; PORT=50001; PROTOCOL=TCPIP; UID={user};PWD={user_pw};SECURITY=ssl;"

        try:
            ibm_db_conn = ibm_db.connect(conn_string, '', '')
            conn = ibm_db_dbi.Connection(ibm_db_conn)

            self.ibm_db_conn = ibm_db_conn
            self.conn = conn

            return ibm_db_conn
        except Exception as exc:
            logger.error(exc, exc_info=True)
            raise

    @retry(max_retries=3, exceptions=(pd.io.sql.DatabaseError), interval=20, logger=logger)
    def get_results(self, sql) -> pd.DataFrame:
        """
        Execute a query and return a Pandas DF

        :param sql: Query to be executed
        :type sql: string

        :return: Pandas Dataframe
        :rtype: pd.DataFrame
        """
        try:
            df_res = pd.read_sql(sql, self.conn)

            return df_res

        except pd.io.sql.DatabaseError:
            raise
        except Exception as exc:
            logger.error(exc, exc_info=True)
            raise

    @retry(max_retries=3, exceptions=(pd.io.sql.DatabaseError), interval=20, logger=logger)
    def save_to_table(self, df: pd.DataFrame, table_columns: list, table_name: str):
        """
        Save a Pandas DF to a DB2 table

        For pd.io.sql.DatabaseError exceptions it will retry 3 times before thrown a error. 
        Delay: 20 seconds 

        :param df: Pandas DF that contains data to be saved 
        :type df: pd.DataFrame

        :param table_columns: List of columns to be saved 
        :type table_columns: list

        :param table_name: Destination table name
        :type table_name: str

        :return: None
        :rtype: None
        """
        try:
            # Generate insert
            table_parameters = ', '.join("?" * len(table_columns))
            table_cols = ', '.join(table_columns)
            sql = f"INSERT INTO {table_name}({table_cols}) VALUES({table_parameters})"

            # Prepare
            stmt = ibm_db.prepare(self.ibm_db_conn, sql)

            # Generate values
            cols = df[table_columns]
            cols_tuples = tuple([tuple(x) for x in cols.values])
            ibm_db.execute_many(stmt, cols_tuples)

        except pd.io.sql.DatabaseError:
            raise
        except Exception as exc:
            logger.error(exc, exc_info=True)
            raise
