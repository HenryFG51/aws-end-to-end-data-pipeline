import logging

import boto3
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)


class DMTS3(object):
    """Encapsulates an AWS S3 Client"""

    def __init__(self, s3_bucket, region_name=None, aws_access_key_id=None,
                 aws_secret_access_key=None, profile_name=None):
        """
        Constructor method

        It can connect to AWS by:
        * Profile - In this case secret and key should be None
        * Secret/Key - In this case profile should be None
        * AWS Role (Glue, Lambda, etc) - In this case Profile, Secret and Key should be None

        :param s3_bucket: S3 bucket name
        :type s3_bucket: str

        :param region_name: Session region name, defaults to None
        :type region_name: str, optional

        :param aws_access_key_id: AWS Key ID, defaults to None.
        :type aws_access_key_id: str, optional

        :param aws_secret_access_key: AWS Secret Key, defaults to None.
        :type aws_secret_access_key: str, optional

        :param profile_name: aws profile name, defaults to None.
        :type profile_name: str, optional

        :return: None
        :rtype: None
        """
        self.s3_bucket = s3_bucket

        self.region_name = region_name
        self.aws_access_key_id = aws_access_key_id
        self.aws_secret_access_key = aws_secret_access_key
        self.profile_name = profile_name

        self.s3_client = self.get_client()

    def get_client(self):
        """
        Stores the S3 client in a member variable.

        :return: S3 Client
        :rtype: boto3.client.s3
        """
        try:
            session = boto3.session.Session(region_name=self.region_name,
                                            aws_access_key_id=self.aws_access_key_id,
                                            aws_secret_access_key=self.aws_secret_access_key,
                                            profile_name=self.profile_name)

            client = session.client(
                service_name='s3'
            )
        except ClientError as err:
            logger.error(
                "Could not create a Boto3 client to %s. Here's why: %s: %s",
                self.s3_bucket,
                err.response['Error']['Code'], err.response['Error']['Message'])
            logger.error(err, exc_info=True)
            raise
        except Exception as err:
            logger.error(err, exc_info=True)
            raise
        else:
            return client

    def save_to_s3(self, s3_path, data: bytes) -> None:
        """
        Stores an object(using put_object api) to a s3 bucket in the defined s3 path

        :param s3_path: s3 path
        :type s3_path: str

        :param data: the data to be stored on s3
        :type data: bytes

        :return: None
        :rtype: None
        """

        try:
            self.s3_client.put_object(
                Body=data,
                Bucket=self.s3_bucket,
                Key=s3_path
            )
        except ClientError as err:
            logger.error(
                "Couldn't save to S3 %s. %s, %s, %s",
                {self.s3_bucket}, {s3_path}, {err.response['Error']['Code']},
                {err.response['Error']['Message']})
            logger.error(err, exc_info=True)
            raise
        except Exception as err:
            logger.error(err, exc_info=True)
            raise
