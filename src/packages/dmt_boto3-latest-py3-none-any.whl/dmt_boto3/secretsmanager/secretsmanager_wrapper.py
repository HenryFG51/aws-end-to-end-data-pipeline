import base64
import json
import logging

import boto3
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)


class DMTSecretManager(object):
    """Encapsulates an Secret Manager functions"""

    def __init__(self, secret_name, region_name=None, aws_access_key_id=None,
                 aws_secret_access_key=None, profile_name=None):
        """
        Constructor method

        It can connect to AWS by: 
        * Profile - In this case secret and key should be None
        * Secret/Key - In this case profile should be None
        * AWS Role (Glue, Lambda, etc) - In this case Profile, Secret and Key should be None

        :param secret_name: AWS secret name
        :type secret_name: str

        :param region_name: Session region name, defaults to None
        :type region_name: str, optional

        :param aws_access_key_id: AWS Key ID, defaults to None.
        :type aws_access_key_id: str, optional

        :param aws_secret_access_key: AWS Secret Key, defaults to None.
        :type aws_secret_access_key: str, optional

        :param profile_name: aws profile name, defaults to None.
        :type profile_name: str, optional

        :return: None
        :rtype: None
        """
        self.secret_name = secret_name

        self.region_name = region_name
        self.aws_access_key_id = aws_access_key_id
        self.aws_secret_access_key = aws_secret_access_key
        self.profile_name = profile_name

        self.sm_client = self.get_client()

    def get_client(self):
        """
        Stores the Secret Manager client in a member variable.

        :return: Secret Manager Client
        :rtype: boto3.client.secretmanager
        """
        try:
            session = boto3.session.Session(region_name=self.region_name,
                                            aws_access_key_id=self.aws_access_key_id,
                                            aws_secret_access_key=self.aws_secret_access_key,
                                            profile_name=self.profile_name)

            client = session.client(
                service_name='secretsmanager'
            )
        except ClientError as err:
            logger.error(
                "Could not create a Boto3 session to %s. Here's why: %s: %s",
                self.secret_name,
                err.response['Error']['Code'], err.response['Error']['Message'])
            logger.error(err, exc_info=True)
            raise
        except Exception as err:
            logger.error(err, exc_info=True)
            raise
        else:
            return client

    def get_secret(self):
        """
        :return: Secrets Manager Dict
        :rtype: Secrets Manager Dict
        """
        # In this sample we only handle the specific exceptions for the 'GetSecretValue' API.
        # See https://docs.aws.amazon.com/secretsmanager/latest/apireference/API_GetSecretValue.html
        # We rethrow the exception by default.
        try:
            get_secret_value_response = self.sm_client.get_secret_value(
                SecretId=self.secret_name
            )

        except ClientError as err:
            logger.error(
                "Could not get secret details. Secret: %s. Here's why: %s: %s",
                self.secret_name,
                err.response['Error']['Code'], err.response['Error']['Message'])
            logger.error(err, exc_info=True)
            raise
        except Exception as err:
            logger.error(err, exc_info=True)
            raise
        else:
            # Decrypts secret using the associated KMS CMK.
            # Depending on whether the secret is a string or binary, one of these fields will be populated.
            if 'SecretString' in get_secret_value_response:
                secret = get_secret_value_response['SecretString']
            else:
                secret = base64.b64decode(
                    get_secret_value_response['SecretBinary'])

        return json.loads(secret)  # returns the secret as dictionary
